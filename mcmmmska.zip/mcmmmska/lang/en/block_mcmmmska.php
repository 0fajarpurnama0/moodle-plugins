<?php
$string['pluginname'] = 'Mouse Tracking and Animation';
$string['mcmmmska'] = 'Mouse Click Mouse Move Mouse Scroll Keyboard Animation';
$string['mcmmmska:addinstance'] = 'Add a new Mouse Tracking and Animation block';
$string['mcmmmska:myaddinstance'] = 'Add a new Mouse Tracking and Animation block to the My Moodle page';
$string['blockstring'] = 'Add text';
$string['blocktitle'] = 'Add title';
$string['labelallowhtml'] = 'Allow HTML';
$string['descallowhtml'] = 'Description here';
$string['headerconfig'] = 'Allow HTML Settings';
$string['descconfig'] = 'Description here';
