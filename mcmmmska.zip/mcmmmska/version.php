<?php
$plugin->component = 'block_mcmmmska';
$plugin->version = 2015051200;
$plugin->requires = 2015051100;
