<?php
$settings->add(new admin_setting_heading(
 'headerconfig',
 get_string('headerconfig', 'block_mcmmmska'),
 get_string('descconfig', 'block_mcmmmska')
));

$settings->add(new admin_setting_configcheckbox(
 'mcmmmska/Allow_HTML',
 get_string('labelallowhtml', 'block_mcmmmska'),
 get_string('descallowhtml', 'block_mcmmmska'),
 '0'
));

$allowHTML = get_config('mcmmmska', 'Allow_HTML');
