Other files are Clean theme files except:

amd/*
javascript/*
style/mousetrail.css
style/jquery-ui.css

and classes/core_renderer.php is modified to render the .js and config.php is modified to render external .js and .css to the head.